package com.teamtreehouse.jobs;

import com.teamtreehouse.jobs.model.Job;
import com.teamtreehouse.jobs.service.JobService;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class App {

  public static void main(String[] args) {
    JobService service = new JobService();
    boolean shouldRefresh = false;
    try {
      if (shouldRefresh) {
        service.refresh();
      }
      List<Job> jobs = service.loadJobs();
      System.out.printf("Total jobs:  %d %n %n", jobs.size());
      explore(jobs);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private static void explore(List<Job> jobs) {
    // Your amazing code below...
	  changeDateToNewFormat(jobs);
  }
  
  private static Function<String, String> createDateStringConverter(DateTimeFormatter inFormatter, DateTimeFormatter outFormatter) {
	  return dateString -> LocalDateTime.parse(dateString, inFormatter).format(outFormatter);
  }
  
  private static void changeDateToNewFormat(List<Job> jobs) {
	  Function<String, LocalDateTime> convertStringToDateTime =
			  dateString -> LocalDateTime.parse(dateString, DateTimeFormatter.RFC_1123_DATE_TIME);
	  
	  Function<LocalDateTime, String> convertDateTimeToCustomFormat = 
			  date -> date.format(DateTimeFormatter.ofPattern("M / d / YY"));
	  
	  Function<String, String> customFormatConverter =
			  convertStringToDateTime.andThen(convertDateTimeToCustomFormat);
			  
	  jobs.stream()
	  .map(Job::getDateTimeString)
	  //.map(customFormatConverter)
	  .map(App.createDateStringConverter(DateTimeFormatter.RFC_1123_DATE_TIME, DateTimeFormatter.ISO_LOCAL_DATE))
	  .limit(5)
	  .forEach(System.out::println);
  }
  
  private static void demoHigherOrderFunctions(List<Job> jobs) {
	  Predicate<Job> caJobChecker = job -> job.getState().equals("CA");
	  Job caJob = jobs.stream()
			  .filter(caJobChecker.and(App::isJunior))
			  .findFirst()
			  .orElseThrow(NullPointerException::new);

	  System.out.println("First job:" + caJob);
	  emailIfMatches(caJob, caJobChecker.and(App::isJunior));
  }
  
  public static void emailIfMatches(Job job, Predicate<Job> checker) {
	  if (checker.test(job)) {
		  System.out.print("Sending email about " + job);
	  }
  }
  
  private static void filterCompaniesByFirstLetter(List<Job> jobs, String letter) {
	  List<String> companies = getCompanies(jobs);
	  
	  companies.stream()
	  .peek(company -> System.out.println("=====> "+company))
	  .filter(company -> company.startsWith(letter))
	  .forEach(System.out::println);
  }

private static List<String> getCompanies(List<Job> jobs) {
	List<String> companies = jobs.stream()
			  .map(Job::getCompany)
			  .distinct()
			  .sorted()
			  .collect(Collectors.toList());
	return companies;
}
  
  private static void displayCompaniesByPage(List<Job> jobs, int pageSize) {
	  List<String> companies = getCompanies(jobs);
	  
	  int numPages = companies.size() / pageSize;
	  
	  IntStream.iterate(1, i-> i + pageSize)
	  .mapToObj(i -> String.format("%d. %s", i, companies.get(i-1)))
	  .limit(numPages)
	  .forEach(System.out::println);
  }
  
  private static void displayCompaniesMenu(List<Job> jobs) {
	  List<String> companies = getCompanies(jobs);
	  
	  printCompaniesImperatively(companies);
	  printCompaniesByRange(companies);
  }
  
  private static void printCompaniesByRange(List<String> companies) {
	  IntStream.rangeClosed(1, 20)
	  .mapToObj(i -> String.format("%d. %s", i, companies.get(i-1)))
	  .forEach(System.out::println);
  }
  
  private static void printCompaniesImperatively(List<String> companies) {
	  for (int i=0; i<20; i++) {
		  System.out.printf("%d. %s %n", i+1, companies.get(i));
	  }
  }
  
  private static void printSearchTermInJobsTitles (String searchTerm, List<Job> jobs) {
	  Optional<Job> foundJob = searchJobsTitles(searchTerm, jobs);
	  System.out.println(foundJob
			  .map(Job::getTitle)
			  .orElse("No jobs found"));
  }
  
  private static Optional<Job> searchJobsTitles(String searchTerm, List<Job> jobs) {
	  return jobs.stream()
			  .filter(job -> job.getTitle().contains(searchTerm))
			  .findFirst();
  }
  
  private static Optional<String> getNameOfLongestCompanyName(List<Job> jobs) {
	  return jobs.stream()
			  .map(Job::getCompany)
			  .max(Comparator.comparingInt(String::length));
  }
  
  private static OptionalInt getLengthOfLongestCompanyName(List<Job> jobs) {
	  return jobs.stream()
	  .map(Job::getCompany)
	  .mapToInt(String::length)
	  .max();
  }
  
  private static Map<String, Long> getSnippetWordCountsStream(List<Job> jobs) {
	  return jobs.stream()
			  .map(Job::getSnippet)
			  .map(snippet -> snippet.split("\\W+"))
			  .flatMap(Stream::of)
			  .filter(word -> word.length() > 0)
			  .map(String::toLowerCase)
			  .collect(Collectors.groupingBy(
					  Function.identity(),
					  Collectors.counting()
				));
  }
  
  public static Map<String, Long> getSnippetWordCountsImperatively(List<Job> jobs) {

	  Map<String, Long> wordCounts = new HashMap<>();

	  for (Job job : jobs) {
	    String[] words = job.getSnippet().split("\\W+");
	    for (String word : words) {
	      if (word.length() == 0) {  
	        continue;
	      }
	      String lWord = word.toLowerCase();
	      Long count = wordCounts.get(lWord);
	      if (count == null) {
	        count = 0L;
	      }
	      wordCounts.put(lWord, ++count);
	    }
	  }
	  return wordCounts;
	 }

  
  private static List<String> getContentDeclaratively(List<Job> jobs) {
	  return jobs.stream()
			  .filter(App::isJunior)
			  .map(Job::getContent)
			  .limit(3)
			  .collect(Collectors.toList());
  }
  
  private static List<String> getContentImperatively(List<Job> jobs) {
	List<String> content = new ArrayList<String>();
	  for (Job job : jobs) {
		 if (isJunior(job)) {
			 content.add(job.getContent());
			 if (content.size() >= 3) {
				 break;
			 }
		 }
	  }
	  return content;
	}
  
  private static List<Job> getThreeJuiorJobsDeclaratively(List<Job> jobs) {
	  return jobs.stream()
			  .filter(App::isJunior)
			  .limit(3)
			  .collect(Collectors.toList());
  }
  
  private static List<Job> getThreeJuiorJobsImperatively(List<Job> jobs) {
	List<Job> juniorJobs = new ArrayList<Job>();
	  for (Job job : jobs) {
		 if (isJunior(job)) {
			 juniorJobs.add(job);
			 if (juniorJobs.size() >= 3) {
				 break;
			 }
		 }
	  }
	  return juniorJobs;
	}

  private static boolean isJunior(Job job) {
	  String title = job.getTitle().toLowerCase();
	  return title.contains("junior") || title.contains("jr");
  }
  
	private static void printChicagoJobsStream(List<Job> jobs) {
		jobs.stream()
		  .filter(job -> job.getState().equals("IL"))
		  .filter(job -> job.getCity().equals("Chicago"))
		  .forEach(System.out::println);
	}

	private static void printChicagoJobsImperatively(List<Job> jobs) {
		for (Job job : jobs) {
			  if (job.getState().equals("IL") && job.getCity().equals("Chicago")){
				  System.out.println(job);
			  }
		  }
	}
}
